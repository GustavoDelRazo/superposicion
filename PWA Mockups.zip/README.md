
  # PWA Mockups

  This is a code bundle for PWA Mockups. The original project is available at https://www.figma.com/design/GW3IYfCV8IOvXV9bDIYfm3/PWA-Mockups.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  